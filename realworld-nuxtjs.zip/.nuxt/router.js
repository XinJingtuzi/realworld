import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _4078dd8a = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _d8b82182 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _3ddb7dee = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _82a6196e = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _af9cf2fa = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _34aa03cd = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _b51192d4 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _4078dd8a,
    children: [{
      path: "",
      component: _d8b82182,
      name: "home"
    }, {
      path: "/login",
      component: _3ddb7dee,
      name: "login"
    }, {
      path: "/register",
      component: _3ddb7dee,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _82a6196e,
      name: "profile"
    }, {
      path: "/settings",
      component: _af9cf2fa,
      name: "settings"
    }, {
      path: "/editor",
      component: _34aa03cd,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _b51192d4,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
